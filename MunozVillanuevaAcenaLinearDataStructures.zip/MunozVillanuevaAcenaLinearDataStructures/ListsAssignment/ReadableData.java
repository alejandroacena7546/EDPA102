/*********************************************************************
 * 
 * Interface Name: ReadableData
 * Author/s name: Alejandro Aceña Tirado / Javier Villanueva Crespo / Rodrigo Muñoz Martin
 * Release/Creation date: 2025/26
 * Interface version: 1.0
 * Interface description: Defines a contract for classes that can read
 * their fields from a string array.
 * 
 **********************************************************************/

public interface ReadableData {

    public void readFields(String [] fields); 

}
