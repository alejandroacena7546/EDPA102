import java.io.*;
import java.util.*;

/*********************************************************************
 * 
 * Class Name: SequentialFile
 * Author/s name: Alejandro Aceña Tirado / Javier Villanueva Crespo / Rodrigo Muñoz Martin
 * Release/Creation date: 2025/26
 * Class version: 1.0
 * Class description: Generic class for reading CSV files sequentially,
 * parsing lines into objects that implement ReadableData interface.
 * 
 **********************************************************************/

public class SequentialFile <T extends ReadableData>{

private Scanner ENTRADA; // Scanner to read the file
private String character; // Delimiter character for splitting lines

/*********************************************************************
* 
* Method name: SequentialFile (Constructor)
* 
* Description of the Method: Creates a new SequentialFile object that
* opens and prepares a file for sequential reading.
* 
* Calling arguments: 
* - String name: Path to the file to be opened
* - String character: Delimiter character used to split fields in each line
* 
* Return value: N/A (Constructor)
* 
* Required Files: The file specified in 'name' parameter must exist
* 
* List of Checked Exceptions: 
* - IOException: Thrown if the file cannot be opened or read
* 
**********************************************************************/

    public SequentialFile(String name, String character) throws IOException{

        ENTRADA= new Scanner(new FileReader(name));

        this.character= character;

    }

/*********************************************************************
* 
* Method name: closeFile
* 
* Description of the Method: Closes the file and releases associated
* system resources.
* 
* Calling arguments: None
* 
* Return value: void
* 
**********************************************************************/

    public void closeFile(){

        ENTRADA.close();

    }

/*********************************************************************
* 
* Method name: readLine
* 
* Description of the Method: Reads the next line from the file, splits
* it using the delimiter, and populates the provided object with the
* parsed data.
* 
* Calling arguments: 
* - T elemento: Object that implements ReadableData interface where
*   the parsed data will be stored
* 
* Return value: boolean - true if a line was successfully read and 
* parsed, false if end of file is reached
* 
**********************************************************************/

    public boolean readLine(T elemento){

        boolean found= false;
    
        if(ENTRADA.hasNextLine()){

            String line= ENTRADA.nextLine();

            String [] fields= line.split(character);

            elemento.readFields(fields);

            found= true;

        }
        return found;
    }

/*********************************************************************
* 
* Method name: skipLine
* 
* Description of the Method: Skips the next line in the file without
* processing it. Useful for skipping headers.
* 
* Calling arguments: None
* 
* Return value: void
* 
**********************************************************************/

    public void skipLine(){

        if(ENTRADA.hasNextLine()){

            ENTRADA.nextLine();

        }
    }

/*********************************************************************
* 
* Method name: checkEOF
* 
* Description of the Method: Checks if the end of file has been reached.
* 
* Calling arguments: None
* 
* Return value: boolean - true if end of file is reached, false otherwise
* 
**********************************************************************/

    public boolean checkEOF(){

        boolean EOF= false;

        if(!ENTRADA.hasNextLine()){
            EOF= true;
        }   

        return EOF;
    }

}