/*********************************************************************
 * 
 * Class Name: Artist
 * Author/s name: Alejandro Aceña Tirado / Javier Villanueva Crespo / Rodrigo Muñoz Martin
 * Release/Creation date: 2025/26
 * Class version: 1.0
 * Class description: Represents an artist performing at the Glastonbury
 * Madrid 2025 festival, containing information about their performance
 * such as name, genre, day, stage, duration, and popularity.
 * 
 **********************************************************************/

public class Artist implements ReadableData{

    private String name;
    private String genre;
    private int day;
    private String stage;
    private int duration;
    private int popularity;

/*********************************************************************
* 
* Method name: readFields
* 
* Description of the Method: Reads and parses artist data from an array
* of strings, converting them into the appropriate data types and 
* assigning them to the instance variables.
* 
* Calling arguments: 
* - String[] fields: Array containing artist data in order: name, genre,
*   day, stage, duration, popularity
* 
* Return value: void
* 
**********************************************************************/

    public void readFields(String [] fields) {

        this.name= fields[0];
        this.genre= fields[1];
        this.day= Integer.parseInt(fields[2]);
        this.stage= fields[3];
        this.duration= Integer.parseInt(fields[4]);
        this.popularity= Integer.parseInt(fields[5]);
    }

    public String getName() {
        return name;
    }

    public String getGenre() {
        return genre;
    }

    public int getDay() {
        return day;
    }

    public String getStage() {
        return stage;
    }

    public int getDuration() {
        return duration;
    }

    public int getPopularity() {
        return popularity;
    }
    public String toString(){
        return "Name: " + this.name + " Genre: " + this.genre + " Day: " + this.day + " Stage: " + this.stage + " Duration: " + this.duration + " Popularity: " + this.popularity;
    }

}
