import java.util.*;

/*********************************************************************
* 
* Class Name: S5Lab
* Author/s name: Alejandro Aceña Tirado / Javier Villanueva Crespo / Rodrigo Muñoz Martin
* Release/Creation date: 2025/26
* Class version: 1.0
* Class description: Main class for the Glastonbury Madrid 2025 festival
* management system. Reads artist data from a CSV file, organizes the
* festival schedule by day and stage, and displays statistical information.
* 
**********************************************************************/

public class S5Lab {
    
//Comparator to sort artists by popularity, duration and name,
private static Comparator <Artist> comparator= Comparator.comparingInt(Artist::getPopularity).thenComparingInt(Artist::getDuration).thenComparing(Artist::getName);

/*********************************************************************
 * 
 * Method name: main
 * 
 * Description of the Method: Main method that orchestrates the entire
 * program flow: reads artist data from a CSV file, displays the festival
 * schedule organized by day and stage, and prints statistical information.
 * 
 * Calling arguments: 
 * - String[] args: Command line arguments (not used)
 * 
 * Return value: void
 * 
 * Required Files: artists.csv file must exist at the specified path
 * 
 * List of Checked Exceptions: 
 * - Exception: Caught if file cannot be opened or read
 * 
 **********************************************************************/

    public static void main(String [] args){

        try{

            String path; // Variable to store the path of the file
            Scanner ENTRADA = new Scanner(System.in); // Scanner to the user input
            
            System.out.println("Enter the path to the CSV file:");
            path= ENTRADA.nextLine();

            SequentialFile <Artist> file = new SequentialFile<>(path, ";");        
            file.skipLine();
        
            List <Artist> allArtists= new ArrayList<>();

            while(!file.checkEOF()){
                Artist a= new Artist();
                if(file.readLine(a)){allArtists.add(a);}
            }
            file.closeFile();
            System.out.println(allArtists.size() + " artists loaded succesfully.");

            printSchedules(allArtists);
            printStats(allArtists);

        }catch (Exception e){System.out.println("The file can not be opened, check the path or the file.");}
    }

/*********************************************************************
 * 
 * Method name: printSchedules
 * 
 * Description of the Method: Organizes all artists by festival day and
 * prints the complete schedule for all three days of the festival.
 * 
 * Calling arguments: 
 * - List<Artista> allArtists: List containing all artists to be scheduled
 * 
 * Return value: void
 * 
 **********************************************************************/

    public static void printSchedules(List <Artist> allArtists){

        System.out.println("=====GLASTONBURY MADRID 2025=====");

        List <Artist> day1= new ArrayList<>();
        List <Artist> day2= new ArrayList<>();
        List <Artist> day3= new ArrayList<>();

        for(int i=0; i<allArtists.size(); i++){

            if(allArtists.get(i).getDay()==1){day1.add(allArtists.get(i));}
            if(allArtists.get(i).getDay()==2){day2.add(allArtists.get(i));}
            if(allArtists.get(i).getDay()==3){day3.add(allArtists.get(i));}
        
        }

        printDay(day1, 1);
        printDay(day2, 2);
        printDay(day3, 3);

    }

/*********************************************************************
 * 
 * Method name: printDay
 * 
 * Description of the Method: Organizes artists for a specific day by
 * stage (Main and River), sorts them according to the comparator, and
 * prints the schedule for both stages.
 * 
 * Calling arguments: 
 * - List<Artista> day: List of artists performing on this day
 * - int numberDay: Day number (1, 2, or 3)
 * 
 * Return value: void
 * 
 **********************************************************************/

    public static void printDay(List <Artist> day, int numberDay){

        List <Artist> mainStage= new ArrayList<>();
        List <Artist> riverStage= new ArrayList<>();

        for(int i=0; i<day.size(); i++){
            if(day.get(i).getStage().equals("Main")){mainStage.add(day.get(i));}
            if(day.get(i).getStage().equals("River")){riverStage.add(day.get(i));}
        }

        mainStage.sort(comparator);
        riverStage.sort(comparator);

        printStage(mainStage, numberDay, "Main", "14:00");
        printStage(riverStage, numberDay, "River", "13:30");

    }

/*********************************************************************
 * 
 * Method name: printStage
 * 
 * Description of the Method: Prints the schedule for a specific stage
 * on a specific day, showing all artists performing on that stage.
 * 
 * Calling arguments: 
 * - List<Artista> stage: List of artists performing on this stage
 * - int numberDay: Day number
 * - String stageName: Name of the stage (Main or River)
 * - String startingHour: Time when performances begin
 * 
 * Return value: void
 * 
 **********************************************************************/

    public static void printStage(List <Artist> stage, int numberDay, String stageName, String startingHour){

        System.out.println("Day " + numberDay + " " + stageName + " stage" + " starting at " + startingHour);
        
        for(int i=0; i<stage.size(); i++){
            System.out.println(stage.get(i).toString());
        }

    }

/*********************************************************************
 * 
 * Method name: printStats
 * 
 * Description of the Method: Calculates and displays statistical
 * information about the festival including average popularity by stage
 * and total music time.
 * 
 * Calling arguments: 
 * - List<Artista> artists: List of all artists in the festival
 * 
 * Return value: void
 * 
 **********************************************************************/

    public static void printStats(List <Artist> artists){

        double popMeanRiver=0.0; // Average popularity for River stage
        double popMeanMain=0.0; // Average popularity for Main stage
        double musicTime=0.0; // Total duration of all performances
        int totalPopMain=0; // Sum of popularity scores for Main stage
        int totalPopRiver=0; // Sum of popularity scores for River stage
        int mainArtists=0; // Count of artists on Main stage
        int riverArtists=0; // Count of artists on River stage

        for(int i=0; i<artists.size(); i++){

            if(artists.get(i).getStage().equals("Main")){
                totalPopMain+= (artists.get(i).getPopularity());
                mainArtists+=1;
            }else{
                totalPopRiver+= (artists.get(i).getPopularity());
                riverArtists+=1;
            }
            musicTime+= (artists.get(i).getDuration());

        }

        // Calculate averages
        popMeanMain= (totalPopMain/mainArtists);
        popMeanRiver= (totalPopRiver/riverArtists);

        // Display stats.
        System.out.println("Main stage average popularity: " + popMeanMain);
        System.out.println("River stage average popularity: " + popMeanRiver);
        System.out.println("Total music time: " + musicTime + " minutes");
    }
}
