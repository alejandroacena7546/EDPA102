/*********************************************************************
 * 
 * Class Name: Match
 * Author/s name: Alejandro Aceña Tirado / Javier Villanueva Crespo / Rodrigo Muñoz Martin
 * Release/Creation date: 1/11/2025
 * Class version: 1.0
 * Class description: Represents a matchmaking result between two players,
 * including subscription type and match duration information.
 * 
 **********************************************************************/

public class Match {

    public final boolean premium; // true=premium, false=non-premium
    public final String kind;     // "LONG" o "SHORT"
    public final Request a; // First player in the match
    public final Request b; // Second player in the match

    /*********************************************************************
     * 
     * Method name: Match (Constructor)
     * 
     * Description of the Method: Creates a new Match object with the specified
     * subscription type, match kind, and two player requests.
     * 
     * Calling arguments: 
     * - boolean premium: Indicates if this is a premium match
     * - String kind: Type of match ("LONG" or "SHORT")
     * - Request a: First player's request
     * - Request b: Second player's request
     * 
     **********************************************************************/

    public Match(boolean premium, String kind, Request a, Request b) {
        this.premium = premium;
        this.kind = kind;
        this.a = a;
        this.b = b;
    }
    @Override
    public String toString() {
        String type; // Distinguish between premium and non-premium.
        if(premium){
            type = "PREMIUM";
        }else{
            type = "NON-PREMIUM";
        }
        return "Match [" + type + " / " + kind + "]: " + a.getPlayerID() + "(skill=" + a.getSkillLevel() + ") vs " + b.getPlayerID() + "(skill=" + b.getSkillLevel() + ")";
    }
}
