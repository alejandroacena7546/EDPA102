/*********************************************************************
 * 
 * Class Name: Request
 * Author/s name: Alejandro Aceña Tirado / Javier Villanueva Crespo / Rodrigo Muñoz Martin
 * Release/Creation date: 1/11/2025
 * Class version: 1.0
 * Class description: Represents a matchmaking request from a player,
 * containing player information, subscription status, skill level,
 * and preferred match type.
 * 
 **********************************************************************/

public class Request implements ReadableData {
    private String  RequestID; // Unique identifier for the request
    private String PlayerID; // Unique identifier for the player
    private boolean PremiumSuscription; // Premium subscription status
    private int SkillLevel; // Player's skill level (numeric)
    private char matchType; // Match type preference ('L' for Long, 'S' for Short)

    /*********************************************************************
     * 
     * Method name: readFields
     * 
     * Description of the Method: Reads and parses player request data from
     * a string array, typically obtained from a CSV file line.
     * 
     * Calling arguments: 
     * - String[] fields: Array containing request data in order:
     *   [RequestID, PlayerID, PremiumSuscription, SkillLevel, MatchType]
     * 
     * Return value: void
     * 
     **********************************************************************/

    public void readFields(String[] fields) {
        this.RequestID = fields[0];
        this.PlayerID = fields[1];
        this.PremiumSuscription = Boolean.parseBoolean(fields[2]);
        this.SkillLevel = Integer.parseInt(fields[3]);
        this.matchType = fields[4].charAt(0);
    }

    public String getRequestID() {
        return RequestID;
    }
    public String getPlayerID() {
        return PlayerID;
    }
    public boolean getPremiumSuscription() {
        return PremiumSuscription;
    }
    public int getSkillLevel() {
        return SkillLevel;
    }
    public char getMatchType() {
        return matchType;
    }
    @Override
    public String toString() {
        return "RequestID: " + RequestID + ", PlayerID: " + PlayerID + ", PremiumSuscription: " + PremiumSuscription +
        ", SkillLevel: " + SkillLevel + ", MatchType: " + matchType;
    }
}
