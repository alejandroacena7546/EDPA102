import java.util.*;

/*********************************************************************
 * 
 * Class Name: Matchmaker
 * Author/s name: Alejandro Aceña Tirado / Javier Villanueva Crespo / Rodrigo Muñoz Martin
 * Release/Creation date: 1/11/2025
 * Class version: 1.0
 * Class description: Manages matchmaking queues and creates matches between
 * players. Prioritizes premium players and uses skill-based matching for
 * premium queues and FIFO for non-premium queues.
 * 
 **********************************************************************/

class Matchmaker {

    private final int premiumMatchesPerCyclePerQueue; // Number of premium matches per queue per cycle

    private final Queue<Request> premiumLong; // Priority queue for premium long matches
    private final Queue<Request> premiumShort; // Priority queue for premium short matches
    private final Deque<Request> freeLong; // FIFO queue for non-premium long matches
    private final Deque<Request> freeShort; // FIFO queue for non-premium short matches

    private static int cycleCount = 1; // Counter for matchmaking cycles

    /*********************************************************************
     * 
     * Method name: Matchmaker (Constructor)
     * 
     * Description of the Method: Initializes the matchmaker with four queues
     * (premium and non-premium for long and short matches) and sets the
     * number of premium matches per cycle.
     * 
     * Calling arguments: 
     * - int premiumMatchesPerCyclePerQueue: Maximum number of premium matches
     *   to create per queue in each cycle
     * 
     **********************************************************************/

    public Matchmaker(int premiumMatchesPerCyclePerQueue) {
        this.premiumMatchesPerCyclePerQueue = premiumMatchesPerCyclePerQueue;

        Comparator<Request> bySkillDesc = Comparator.comparingInt(Request::getSkillLevel).reversed(); // Comparing by skill level

        // Premium queues use priority based on skill level (descending)
        this.premiumLong  = new PriorityQueue<>(bySkillDesc);
        this.premiumShort = new PriorityQueue<>(bySkillDesc);

        // Non-premium queues use FIFO (First In First Out)
        this.freeLong  = new ArrayDeque<>();
        this.freeShort = new ArrayDeque<>();
    }

    /*********************************************************************
     * 
     * Method name: enqueue
     * 
     * Description of the Method: Adds a player request to the appropriate
     * queue based on subscription type and match type preference.
     * 
     * Calling arguments: 
     * - Request r: The player request to be queued
     * 
     * Return value: void
     * 
     **********************************************************************/

    public void enqueue(Request r) {

        if (r.getPremiumSuscription()) {
            if (r.getMatchType() == 'L') {
                premiumLong.offer(r);
            } else if (r.getMatchType() == 'S') {
                premiumShort.offer(r);
            }
        }else {
            if (r.getMatchType() == 'L') {
                freeLong.addLast(r);
            }else if (r.getMatchType() == 'S') {
                freeShort.addLast(r);
            }
        }
    }

    /*********************************************************************
     * 
     * Method name: canMakeAnyMatch
     * 
     * Description of the Method: Checks if any queue has at least 2 players,
     * which is the minimum required to create a match.
     * 
     * Calling arguments: None
     * 
     * Return value: boolean - true if at least one match can be created,
     * false otherwise
     * 
     **********************************************************************/

    private boolean canMakeAnyMatch() {
        return premiumLong.size()  >= 2
            || premiumShort.size() >= 2
            || freeLong.size()     >= 2
            || freeShort.size()    >= 2;
    }

    /*********************************************************************
     * 
     * Method name: runOneCycle
     * 
     * Description of the Method: Executes one matchmaking cycle following
     * a specific order: premium long matches (up to N), premium short
     * matches (up to N), one non-premium long match, one non-premium short
     * match. Prints all created matches.
     * 
     * Calling arguments: None
     * 
     * Return value: void
     * 
     **********************************************************************/

    private void runOneCycle() {
        System.out.println("=== Cycle " + (cycleCount++) + " ===");

        // 1) Premium LONG: up to N matches
        for (int i = 0; i < premiumMatchesPerCyclePerQueue; i++) {
            if (premiumLong.size() >= 2) {
                Request a = premiumLong.poll(); // highest priority player
                Request b = premiumLong.poll();
                Match m = new Match(true, "LONG", a, b);
                System.out.println(m);
            }
        }

        // 2) Premium SHORT: up to N matches
        for (int i = 0; i < premiumMatchesPerCyclePerQueue; i++) {
            if (premiumShort.size() >= 2) {
                Request a = premiumShort.poll();
                Request b = premiumShort.poll();
                Match m = new Match(true, "SHORT", a, b);
                System.out.println(m);
            }
        }

        // 3) No-premium SHORT: 1 match
        if (freeLong.size() >= 2) {
            Request a = freeLong.removeFirst(); // FIFO: oldesy request first
            Request b = freeLong.removeFirst();
            Match m = new Match(false, "LONG", a, b);
            System.out.println(m);
        }

        // 4) Non-premium SHORT: 1 match
        if (freeShort.size() >= 2) {
            Request a = freeShort.removeFirst();
            Request b = freeShort.removeFirst();
            Match m = new Match(false, "SHORT", a, b);
            System.out.println(m);
        }
    }

    /*********************************************************************
     * 
     * Method name: runAll
     * 
     * Description of the Method: Executes matchmaking cycles repeatedly
     * until no more matches can be created (all queues have fewer than
     * 2 players).
     * 
     * Calling arguments: None
     * 
     * Return value: void
     * 
     **********************************************************************/

    public void runAll() {
        System.out.println("Running matchmaker...");
        while (canMakeAnyMatch()) {
            runOneCycle();
        }
    }
}
