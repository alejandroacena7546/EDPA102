import java.io.*;
import java.util.*;
/*********************************************************************
 * 
 * Class Name: S4lab
 * Author/s name: Alejandro Aceña Tirado / Javier Villanueva Crespo / Rodrigo Muñoz Martin
 * Release/Creation date: 1/11/2025
 * Class version: 1.0
 * Class description: Main class for the matchmaking system. Reads player
 * requests from a CSV file and processes them through the matchmaker.
 * 
 **********************************************************************/

public class S4Lab {
    private static final Scanner keyboard = new Scanner(System.in); // Scanner for user input

    /*********************************************************************
     * 
     * Method name: main
     * 
     * Description of the Method: Entry point of the program. Prompts for
     * configuration, reads player requests from CSV, and runs the matchmaker.
     * 
     * Calling arguments: 
     * - String[] args: Command line arguments (not used)
     * 
     * Return value: void
     * 
     **********************************************************************/

    public static void main(String[] args) {
        int n = askPremiumMatchesPerCycle(); // Number of premium matches per cycle
        Matchmaker matchmaker = new Matchmaker(n);
        readCsv(matchmaker);
        matchmaker.runAll();
    }

    /*********************************************************************
     * 
     * Method name: readCsv
     * 
     * Description of the Method: Prompts the user for a CSV file path,
     * reads all player requests from the file, and adds them to the
     * matchmaker's queues.
     * 
     * Calling arguments: 
     * - Matchmaker matchmaker: The matchmaker object where requests will
     *   be enqueued
     * 
     * Return value: void
     * 
     * Required Files: CSV file with player requests (semicolon-separated)
     * Format: RequestID;PlayerID;PremiumSuscription;SkillLevel;MatchType
     * 
     * List of Checked Exceptions:
     * - IOException: Caught and handled if file cannot be read
     * 
     **********************************************************************/
    
    public static void readCsv(Matchmaker matchmaker) {
        System.out.println("Enter the path to the CSV file:");
        String filePath = keyboard.nextLine(); // Prompt user for CSV file path
        
        try {
            SequentialFile<Request> file = new SequentialFile<>(filePath, ";");
            file.skipLine(); // Skip header line

            while (!file.checkEOF()) {
                Request r = new Request();
                if (file.readLine(r)) {
                    System.out.println(r);
                    matchmaker.enqueue(r);
                }
            }

            file.closeFile();
        } catch (IOException e) {
            System.out.println("Error: File not found or unreadable. Please try again.");
        }
    }
    
    /*********************************************************************
     * 
     * Method name: askPremiumMatchesPerCycle
     * 
     * Description of the Method: Prompts the user for the number of premium
     * matches to create per queue per cycle. Uses default value of 2 if
     * input is empty or invalid.
     * 
     * Calling arguments: None
     * 
     * Return value: int - Number of premium matches per cycle (default: 2)
     * 
     * List of Checked Exceptions:
     * - NumberFormatException: Caught if user enters non-numeric input
     * 
     **********************************************************************/

    public static int askPremiumMatchesPerCycle() {
        System.out.print("Enter the number of premium matches per queue per cycle (default 2): ");
        int n = 2; // Default value

        try {
            String input = keyboard.nextLine();
            if (!input.isEmpty()) {
                n = Integer.parseInt(input);
            }
        } catch (NumberFormatException e) {
            System.out.println("Invalid input. Using default value (2).");
        }

        return n;
    }
}